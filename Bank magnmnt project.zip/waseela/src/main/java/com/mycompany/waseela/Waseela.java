/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.waseela;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author HP
 */
public class Waseela {

    public static void main(String[] args) {
        
        Connection con = null;
        
        try{
            
            con =  DriverManager.getConnection("jdbc:mysql://localhost/testdb/","root","");
            String query ="select from employee";
            Statement stmt =con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while(rs.next()){
                System.out.println(rs.getInt("id")+" "+rs.getString("name")+" "+rs.getString("school"));
                
            }
            
            
        }catch(SQLException ex){
            
            System.out.println(ex.getMessage());
        }
        
        
       
    }
}
